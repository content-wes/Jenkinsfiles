#!groovy

def call(tagName)
{
	node('RHEL6')
	{
	    utilobj = new utils()
        tagBranch = utilobj.getTagBranch()
        if(tagBranch == "preprod")
        {
            try
            {
                stage ('Package')
                {
                    tag = utilobj.getTagNameWithoutrc(tagName)
                    def project = utilobj.getProjectName()
                    sh "tar --exclude='sonar-project.properties' --exclude='Jenkinsfile' --exclude='tests' --exclude='.scannerwork' --exclude='.git' --exclude='README.md' --exclude='README.txt' --exclude='extensions' -cvf ${project}.${tag}.tar *"
                }
            }
            catch(e)
            {
                currentBuild.result = 'FAILURE'
                echo e.toString()
                throw e
            }
		}
	}
}
