#!groovy

def call(tagName, clientName)
{
    node('RHEL6')
    {
        utilobj = new utils()
        Tag_Branch = utilobj.getTagBranch()
        if(Tag_Branch == "preprod" || tagBranch.toLowerCase().startsWith("hotfix-"))
        {
            try
            {
                stage ('upload to Preprod Artifactory')
                {
                    artifactoryUpload(tagName,clientName)
                }
            }
            catch(e)
            {
                currentBuild.result = 'FAILURE'
                echo e.toString()
                throw e
            }
        }
    }
}

def artifactoryUpload(tagName,clientName)
{
    utilobj = new utils()
    def project_name = utilobj.getProjectName()
    def tagBranch= utilobj.getTagBranch()
    def branchName = utilobj.getBranchName(tagBranch)
    def tag = utilobj.getTagNameWithoutrc(tagName)
    def server = Artifactory.server 'artifacts'
    def uploadSpec = """{
    "files": [
    {
        "pattern": "${WORKSPACE}/${project_name}.${tag}.tar",
        "target": "Enterprise-Communications-generic-${branchName}/${clientName}/${project_name}/",
        "props": "tag=${tagName}"
    }]}"""
    def buildInfo1 = server.upload(uploadSpec)
    server.publishBuildInfo(buildInfo1)
    echo "Uploded to artifactory"
}
