#!groovy

def call()
{
	node('RHEL6')
	{
        try
        {
            utilobj = new utils()
            tagBranch = utilobj.getTagBranch()
            if(tagBranch == "preprod" || tagBranch.toLowerCase().startsWith("hotfix-"))
            {
                stage('Build')
                {
                    sh "git checkout ${tagBranch}"
                    packageVersion = sh(script: '/opt/git/bin/git tag --list "v*rc" --sort=-version:refname --points-at HEAD | head -1', returnStdout: true).trim()
                    echo "DEBUG: packageVersion = ${packageVersion}"
                    if(packageVersion == null || packageVersion == "")
                    {
                        error("autoCancelledError");
                    }
                    if(packageVersion.startsWith("v"))
                    {
                        packageVersion = packageVersion.replace("v","version").replace("rc","")
                        sh "echo ${packageVersion} > active.version"
                        sh 'cat active.version'
                    }
                }
            }
        }
        catch(e)
        {
            currentBuild.result = 'FAILURE'
            echo e.toString()
            if (e.message == "autoCancelledError")
            {
                error('cannot find any tag. Please check if your tag name is in lower case characters');
                return
            }
            throw e
        }
	}
}