#!groovy

def getTagBranch()
{
    def Git_Commit = sh(script: "/opt/git/bin/git rev-parse $env.TAG_NAME", returnStdout: true).trim()
    env.GIT_COMMIT = Git_Commit
    def tagBranch = sh(script: "/opt/git/bin/git show-ref | grep $env.GIT_COMMIT | grep 'refs/remotes/origin' | cut -d/ -f4", returnStdout: true).trim()
    echo "Tag Branch : ${tagBranch}"
    return tagBranch
}

def getProjectName()
{
    String gitPath = '/opt/git/bin'
    def gitRepo = sh(script: "cd ${WORKSPACE} && ${gitPath}/git config remote.origin.url", returnStdout: true).trim()
    def gitRepoArr = gitRepo.split(/[\/\.]/);
    String project = gitRepoArr[-2];
    return project
}

def getBranchName(branchname)
{
    if(branchname == "master")
    {
        branchname = "prod"
    }
    else if(branchname == "preprod")
    {
        branchname = "preprod"
    }
    else
    {
        branchname = "dev"
    }
    return branchname
}

def getTagNameWithoutrc(tagName)
{
    if(tagName.endsWith("rc"))
    {
        tagName = tagName.replace("rc","")
        return tagName
    }
}

def notifydev(String buildStatus = 'STARTED',tagName,emailList)
{
        def project_name = getProjectName()
        packageName = "${project_name}.${packageVersion}"
        buildStatus = buildStatus ?: 'SUCCESSFUL'
        def toList = emailList
        def subject = "Dev: '' Artifact ready for testing in Dev Server"
        def summary = "${subject} ${env.BUILD_URL}"
        def details = """
        <p>The artifact "${packageName}" is deployed on to the Dev Server.</p>
        <p>Click here to move the artifact into the Preprod Servers for testing. "<a href="${env.BUILD_URL}/input">${env.JOB_NAME} [${packageVersion}]</a>"</p>"""
        emailext body: details,mimeType: 'text/html', subject: subject, to: toList
}
return this

