#!groovy

def call(emailList)
{
	if (! emailList)
	{
		emailList = sh(script: "cd ${WORKSPACE} && ${gitPath}/git --no-pager show -s --format=%ae", returnStdout: true)
		if (emailList)
		{
			emailList = emailList.trim()
		}
	}
	def host = env.BUILD_URL.split('/')[2].split(':')[0]
	def consoleUrl = env.BUILD_URL.replace(host,"build.west.com")
	def subject = "${currentBuild.currentResult}: ${env.JOB_NAME} [${env.BUILD_NUMBER}] Status"
	def details = """<p>Check console output at "<a href="${consoleUrl}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>"""
	emailNotify(emailList, subject, details)
}
