#!groovy


def call(def dependencies = [])
{
	node('RHEL6')
	{
 	    stage ('SonarQube analysis')
 	    {
  		    try
  		    {
  		        def scannerHome = tool 'SonarQube';
                withSonarQubeEnv('sonarQube')
                {
                    sh "${scannerHome}/bin/sonar-scanner"
                }
            }
            catch (Exception e)
            {
                currentBuild.result = 'FAILURE'
                echo e.toString()
                throw e
            }
		}
    }
} 
