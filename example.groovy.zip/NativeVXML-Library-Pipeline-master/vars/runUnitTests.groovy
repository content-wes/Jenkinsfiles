#!groovy
import groovy.json.JsonSlurper

def call(branchName,unitTestDependencies)
{
	node('RHEL6')
	{
		try
		{
		    deleteDir()
		    checkout scm
			if (fileExists("${WORKSPACE}/phpunit.xml"))
			{
				env.php5 = tool 'php-vxml'
				env.php_home="${tool "phpunit-4"}"
				env.PATH="${env.php_home}/bin:${env.PATH}"
				env.PATH="${env.php5}/bin:${env.PATH}"
                if(branchName == "master")
                {
                    branchName = "prod"
                }
				stage ('Download Dependencies')
				{
					def server = Artifactory.server 'artifacts'
					echo "Download Artifacts started"
					def specPattern = getDependencies(unitTestDependencies,branchName)
					def specDownload =
					"""{
					        "files":${specPattern}
					}"""
					def buildInfo1 =  server.download(specDownload)
					server.publishBuildInfo(buildInfo1)
					archiveArtifacts "*/**"
				}
				stage ('Test')
				{
					sh "${php5}/bin/php -c ${php5}/etc/php.ini ${php_home}/phpunit --configuration ${WORKSPACE}/phpunit.xml -d include_path='${WORKSPACE}/extensions'"
				}
			}
			else
			{
				echo "WARNING: No phpunit.xml exists"
			}
		}
		catch(e)
		{
		    currentBuild.result = 'FAILURE'
		 	echo e.toString()
		 	throw e
		}
	}
}

@NonCPS
def getDependencies(unitTestDependencies,branchName)
{
	def jsonSlurper = new JsonSlurper()
	def resultJson = jsonSlurper.parseText(unitTestDependencies)
	def jsonArr = []
    resultJson.each
    {
	    def teamName = it."team_Name"
	    def gitRepoName = it."git_repo_name"
	    def tagVersion = it."tag_version"
	    def targetDirectory = it."directory"
    	if(tagVersion == "Latest")
    	{
        	if(gitRepoName == "AppEng-NativeVXML-PHP-WicStdVXML")
        	{
        	    tagVersion = "v0.1"
        	}
            else if(gitRepoName == "AppEng-NativeVXML-PHP-WicStd")
            {
                tagVersion = "v0.1"
            }
            else if(gitRepoName == "AppEng-PHP-Wic")
            {
                tagVersion = "v0.1"
            }
    	}
        def downloadSpec =
        """{
                "pattern": "Enterprise-Communications-generic-${branchName}/${teamName}/${gitRepoName}/*.tar",
                "props": "tag=${tagVersion}",
                "target": "${WORKSPACE}/extensions/${targetDirectory}/",
                "explode": "true",
                "flat": "true"
        }"""
	    jsonArr.add(downloadSpec)
    }
	return jsonArr
}