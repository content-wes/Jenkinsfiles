#!groovy

// if emails are not received, have a Jenkins admin check "Manage Jenkins >> Configure System >> Extended E-mail Notification"

def call(String to, String subject, String body, String mimeType = 'text/html')
{
	// to may have a comma-separated list of addresses
	if (! to || ! to.trim())
	{
		echo "WARNING: email address field is empty; email not sent"
		return
	}
	if (! subject || ! subject.trim())
	{
		echo "WARNING: subject field is empty; email not sent"
		return
	}
	if (! body || ! body.trim())
	{
		echo "WARNING: body field is empty; email not sent"
		return
	}

	emailext to: to, subject: subject, body: body, mimeType: mimeType
}
