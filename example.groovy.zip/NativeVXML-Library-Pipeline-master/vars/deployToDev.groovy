#!groovy

def call(tagName, emailList, teamName)
{
    node('RHEL6')
    {
        try
        {
            utilobj = new utils()
            stage ('upload to dev Artifactory')
            {
                // utilobj.artifactoryUpload(tagName, teamName)
            }

		    stage ('Deploy to DEV')
		    {
		       //utilobj.executePlaybook('dev','dev', packageVersion, emailList,  teamName)
		    }

            stage ('Dev Testing Approval')
            {
    	        // utilobj.notifydev(packageVersion, emailList)
    	        timeout ( time: 24, unit: "HOURS" )
    	        {
    	            input "promote Package to Preprod for testing?"
    	        }
            }
        }
        catch(e)
        {
            currentBuild.result = 'FAILURE'
            echo e.toString()
            throw e
        }
    }
}
