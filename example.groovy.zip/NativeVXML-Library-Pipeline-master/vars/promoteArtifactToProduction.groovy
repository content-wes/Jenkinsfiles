#!groovy

def call(tagName,teamName)
{
    node('RHEL6')
    {
        utilobj = new utils()
        tagBranch = utilobj.getTagBranch()
        if(tagBranch == "master")
        {
            try
            {
                stage ('upload to Production Artifactory')
                {
                    def projectName = utilobj.getProjectName()
                    def server = Artifactory.server 'artifacts-swn01'
                    def buildInfo = Artifactory.newBuildInfo()
                    buildInfo.name = "Enterprise-Communications :: ${projectName} :: ${tagName}rc"
                    def promotionConfig = [
                        'targetRepo'         : 'Enterprise-Communications-generic-prod',
                        'buildName'          : buildInfo.name,
                        'buildNumber'        : 1,
                        'comment'            : 'This is the promotion to Production',
                        'status'             : 'Released',
                        'sourceRepo'         : 'Enterprise-Communications-generic-preprod',
                        'includeDependencies': true,
                        'copy'               : true,
                        'failFast'           : true
                    ]
                    server.promote promotionConfig
                }
            }
            catch(e)
            {
                currentBuild.result = 'FAILURE'
                echo e.toString()
                throw e
            }
        }
    }
}