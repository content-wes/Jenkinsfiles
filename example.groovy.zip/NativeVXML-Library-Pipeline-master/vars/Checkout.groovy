#!groovy

def call()
{
	echo "NativeVXML-Library-Pipeline version 0.9.0 for ${env.JOB_NAME}"
	node('RHEL6')
	{
        deleteDir()
        try
        {
            stage ('Checkout')
            {
                checkout([
                            $class: 'GitSCM',
                            branches: scm.branches + [[name: '*/master']] + [[name: '*/preprod']],
                            doGenerateSubmoduleConfigurations: false,
                            extensions: [[$class: 'LocalBranch', localBranch: "**"]],
                            submoduleCfg: [],
                            userRemoteConfigs: scm.userRemoteConfigs
                        ])
            }
        }
        catch(e)
        {
            currentBuild.result = 'FAILURE'
            echo e.toString()
            throw e
        }
	}
}