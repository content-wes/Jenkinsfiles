
def call(tagName)
{
    try
    {
        def preProdTag = false
        if((tagName!=null) && (tagName.contains("rc")))
        {
            assert tagName =~/^v\d+.\d+.\d+rc$/ : "Tag Validation failed in preprod. Please check your tag name"
            preProdTag = true;
        }
        else if(tagName!=null)
        {
            assert tagName =~/^v\d+.\d+.\d+$/ : "Tag Validation failed in master. Please check your tag name"
        }
        echo "preprod tag: ${preProdTag}"
        return preProdTag
    }
    catch (Exception e)
    {
    	currentBuild.result = 'FAILURE'
    	echo e.toString()
    	throw e
    }
}