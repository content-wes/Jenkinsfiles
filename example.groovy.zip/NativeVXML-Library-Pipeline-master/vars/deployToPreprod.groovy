#!groovy

def call(tagName,clientName,destinationPath)
{
    node('RHEL6')
    {
        utilobj = new utils()
        tagBranch = utilobj.getTagBranch()
        if(tagBranch == "preprod" || tagBranch.toLowerCase().startsWith("hotfix-"))
        {
            try
            {
                stage ('Deploy to PreProd')
                {
                    executePlaybook('preprod',tagName,clientName,destinationPath)
                }
            }
            catch(e)
            {
                currentBuild.result = 'FAILURE'
                echo e.toString()
                throw e
            }
        }
    }
}

def executePlaybook(artifactEnvironment,tagName,clientName,destinationPath)
{
    utilobj = new utils()
    def projectName = utilobj.getProjectName()
    def tag = utilobj.getTagNameWithoutrc(tagName)
    packageName = "${projectName}.${tag}.tar"
    ansibleTower(
    			    towerServer: 'tower',
    			    templateType: 'job',
    			    jobTemplate: "NativeVXML-Preprod-Library-Deployment",
    			    importTowerLogs: true,
    			    inventory: 'Dist1',
    			    limit: '',
    			    removeColor: false,
    			    verbose: true,
    			    credential: "NativeVXML-Fdist",
    			    extraVars:"{ \
                                'package_name': '${packageName}', \
                                'fdist_env': 'preprod', \
                                'artifactory_env': '${artifactEnvironment}', \
                                'client_name': '${clientName}',\
                                'repo_name' : '${projectName}', \
                                'dest_folder' : '${destinationPath}' \
                               }"
    			)
}