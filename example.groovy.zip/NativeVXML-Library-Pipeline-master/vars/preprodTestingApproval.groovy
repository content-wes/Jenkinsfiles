def call(String buildStatus = 'STARTED', tagName, emailList, qaTestingApprovalTimeInDays)
{
    tagBranch = ""
    node('RHEL6')
    {
        utilobj = new utils()
        tagBranch = utilobj.getTagBranch()
    }
    if(tagBranch == "master")
    {
        stage('Preprod QA Approval')
        {
            packageName = "${env.JOB_NAME}"
            buildStatus = buildStatus ?: 'SUCCESSFUL'
            def toList = emailList
            def subject = "Preprod: '' Artifact ready for testing in Preprod Server"
            def summary = "${subject} ${env.BUILD_URL}"
            def details = """
            <p>The artifact "${packageName}" is deployed on to the Preprod Server.</p>
            <p>Click here to move the artifact into the Production Server. "<a href="${env.BUILD_URL}/input">${env.JOB_NAME} [${tagName}]</a>"</p>"""
            emailext body: details,mimeType: 'text/html', subject: subject, to: toList
            timeout ( time: "${qaTestingApprovalTimeInDays}", unit: "DAYS" )
            {
                input "promote Package to Production Artifactory?"
            }
        }
    }
}